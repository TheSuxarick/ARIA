# esp32-cam
![Alt Text](https://media.canva.com/v2/image-resize/format:JPG/height:412/quality:92/uri:ifs%3A%2F%2F%2Ffb21f8b1-623b-432a-ac34-45b740fafc66/watermark:F/width:550?csig=AAAAAAAAAAAAAAAAAAAAAJedxUn7SMDUbb19ygSLVvJaW6XXJGNNlLN219Zmhpab&exp=1746193671&osig=AAAAAAAAAAAAAAAAAAAAAIDv4G2XiEWvQQ8KQ0hozsAk5xRLakD8Vu7ftEpTILXj&signer=media-rpc&x-canva-quality=thumbnail_large)
<br>
[Watch the demo on YouTube](https://youtu.be/XqcitDN1cJ0?si=JWIgyL7BiM4365Xf)

## About
This is 360 surveillance camera with person tracking. Also AI is added to help control it.
Camera can record videos and save it in "recordings" folder
It can work on it's own powerbank.
You can manually control 

## In order to start person tracking and recording with voice <br> control you need
1. Clone repo

2. Create virtual environment

3. Enter to the automatic folder by typing this code in terminal: <br>
cd 'Smart ESP32-CAM Surveillance System' <br>
cd AUTOMATIC

4. Download neccesary libraries by: <br>
   pip freeze > requirements.txt

5. then run 'new gpt.py' by-> <br>
   python 'new gpt.py'



No need to run in arduino it is already uploaded. Just follow steps to use that method:

Initial Setup:
Connect the ESP32-CAM to a power source (via USB or power bank).

Create a mobile hotspot with:
SSID: 11t
Password: 123456789

Wait for the ESP32-CAM to connect to the hotspot

Check your phone’s connected devices list and find the IP address of the ESP32-CAM.
_________________________________________


Manual Control Mode:
Open a browser and go to the ESP32-CAM’s IP address (e.g., http://192.168.143.186).
Use the on-screen controls to manually adjust the camera’s position.
Done! You now have live video and directional control.
# ⚙️ Настройка конфиденциальных файлов

## 🔐 Безопасность

Следующие файлы содержат конфиденциальные данные и **НЕ должны** находиться в git:

- `credentials.json` - OAuth credentials для Google
- `token.json` - Access/Refresh токены  
- `.env` - Переменные окружения и API ключи

Эти файлы добавлены в `.gitignore` и не будут залиты в GitHub.

---

## 📝 Как настроить проект локально

### 1. Создать `credentials.json`

```bash
cp credentials.json.example credentials.json
```

Заполните своими данными из Google OAuth:
- Client ID
- Client Secret  
- Redirect URI

### 2. Создать `.env`

```bash
cp .env.example .env
```

Заполните свои API ключи:
- SECRET_KEY (генерируется автоматически)
- GEMINI_API_KEYS
- OWM_KEY
- YOUTUBE_API_KEY

### 3. Первый запуск

```bash
python app.py
```

На этом этапе `token.json` создастся автоматически после первой авторизации.

---

## 🚀 Для других разработчиков

Когда другой человек клонирует репозиторий:

```bash
# 1. Клонировать проект
git clone <repo>
cd "ARIA website"

# 2. Установить зависимости
pip install -r requirements.txt

# 3. Создать credentials.json из примера
cp credentials.json.example credentials.json
# Заполнить свои OAuth данные

# 4. Создать .env из примера
cp .env.example .env
# Заполнить свои API ключи

# 5. Запустить
python app.py
```

---

## ✅ Что можно публиковать в GitHub:

- ✅ `*.py` файлы
- ✅ `requirements.txt`
- ✅ `*.example` файлы (примеры)
- ✅ `.gitignore`
- ✅ `README.md`
- ✅ `models.py`
- ✅ Прочие исходные коды

---

## ❌ Что НЕ публиковать:

- ❌ `credentials.json` (содержит Client Secret)
- ❌ `token.json` (содержит access token)
- ❌ `.env` (содержит API ключи)
- ❌ `client_secret_*.json` файлы
- ❌ Любые файлы с API ключами

---

## 💡 Как проверить перед push:

```bash
# Посмотреть что будет добавлено в git
git status

# Убедиться что нет конфиденциальных файлов
git ls-files | grep -E "(credentials|token|\.env)"
# Не должно ничего вывести!
```

Если вышли случайно - удалить из git (но не из диска):
```bash
git rm --cached credentials.json
git rm --cached token.json
git rm --cached .env
```

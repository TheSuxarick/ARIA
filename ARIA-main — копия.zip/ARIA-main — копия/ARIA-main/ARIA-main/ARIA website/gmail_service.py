"""Gmail Integration Service for ARIA."""

import os
import base64
import json
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google.auth.exceptions import RefreshError
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from pathlib import Path


class GmailService:
    """Handle Gmail authentication and operations."""
    
    def __init__(self):
        self._base_dir = Path(__file__).resolve().parent
        self.credentials_file = self._base_dir / 'credentials.json'
        self.token_file = self._base_dir / 'token.json'
        self.scopes = [
            'https://www.googleapis.com/auth/gmail.readonly',
            'https://www.googleapis.com/auth/gmail.send',
            'https://www.googleapis.com/auth/gmail.modify'
        ]
        self.service = None
        print(f"[Gmail] credentials.json exists: {self.credentials_file.exists()}")
    
    def _load_client_config(self):
        """Load client config from credentials.json using Path (Unicode-safe on Windows)."""
        try:
            raw = self.credentials_file.read_bytes()
            print(f"[Gmail] Read {len(raw)} bytes from credentials.json")
            return json.loads(raw.decode('utf-8-sig'))
        except Exception as e:
            print(f"[Gmail] ERROR reading credentials.json: {e}")
            import traceback
            traceback.print_exc()
            return None

    def get_auth_url(self):
        """Get the authorization URL for Gmail OAuth."""
        if not self.credentials_file.exists():
            return {"error": "Credentials file not found"}
        
        try:
            print(f"[Gmail] Generating auth URL...")
            
            client_config = self._load_client_config()
            if client_config is None:
                return {"error": "Failed to parse credentials.json"}
            
            flow = Flow.from_client_config(
                client_config,
                scopes=self.scopes,
                redirect_uri='http://localhost:5000/api/gmail/callback'
            )
            
            auth_url, state = flow.authorization_url(prompt='consent')
            print(f"[Gmail] OK: Auth URL generated")
            print(f"[Gmail] Auth URL: {auth_url[:80]}...")
            return {"auth_url": auth_url, "state": state}
        except Exception as e:
            print(f"[Gmail] ERROR generating URL: {e}")
            import traceback
            traceback.print_exc()
            return {"error": str(e)}
    
    def exchange_code_for_token(self, auth_code, state=None):
        """Exchange authorization code for access token."""
        if not self.credentials_file.exists():
            print(f"[Gmail] ERROR: Credentials file not found")
            return {"error": "Credentials file not found"}
        
        try:
            print(f"[Gmail] Exchanging code for token...")
            print(f"[Gmail] Code: {auth_code[:20]}...")
            
            client_config = self._load_client_config()
            if client_config is None:
                return {"error": "Failed to read credentials.json"}
            
            flow = Flow.from_client_config(
                client_config,
                scopes=self.scopes,
                redirect_uri='http://localhost:5000/api/gmail/callback'
            )
            
            print(f"[Gmail] Запрос к Google для получения токена...")
            flow.fetch_token(code=auth_code)
            credentials = flow.credentials
            print(f"[Gmail] OK: Token received")
            
            # Save token for later use
            self._save_credentials(credentials)
            print(f"[Gmail] OK: Token saved to token.json")
            
            email = self._get_email_from_credentials(credentials)
            print(f"[Gmail] OK: Email from profile: {email}")
            
            return {
                "success": True,
                "email": email,
                "token": credentials.token,
                "refresh_token": credentials.refresh_token
            }
        except Exception as e:
            print(f"[Gmail] ERROR exchanging code: {e}")
            import traceback
            traceback.print_exc()
            return {"error": str(e)}
    
    def _save_credentials(self, credentials):
        """Save credentials to file for later use."""
        token_data = {
            'token': credentials.token,
            'refresh_token': credentials.refresh_token,
            'token_uri': credentials.token_uri,
            'client_id': credentials.client_id,
            'client_secret': credentials.client_secret,
            'scopes': credentials.scopes
        }
        
        with open(self.token_file, 'w') as f:
            json.dump(token_data, f)
    
    def _load_credentials(self):
        """Load saved credentials from file."""
        if not self.token_file.exists():
            return None
        
        try:
            with open(self.token_file, 'r') as f:
                token_data = json.load(f)
            
            credentials = Credentials(
                token=token_data.get('token'),
                refresh_token=token_data.get('refresh_token'),
                token_uri=token_data.get('token_uri'),
                client_id=token_data.get('client_id'),
                client_secret=token_data.get('client_secret'),
                scopes=token_data.get('scopes')
            )
            
            # Refresh if needed
            if credentials.expired and credentials.refresh_token:
                credentials.refresh(Request())
                self._save_credentials(credentials)
            
            return credentials
        except Exception as e:
            print(f"Error loading credentials: {e}")
            return None
    
    def get_service(self):
        """Get Gmail service instance."""
        if self.service is not None:
            return self.service
        
        credentials = self._load_credentials()
        if credentials is None:
            print("[Gmail] No valid credentials found")
            return None
        
        try:
            self.service = build('gmail', 'v1', credentials=credentials)
            print("[Gmail] Service initialized successfully")
            return self.service
        except Exception as e:
            print(f"[Gmail] Error building service: {e}")
            return None
    
    def get_emails(self, max_results=10):
        """Fetch emails from Gmail inbox."""
        service = self.get_service()
        if service is None:
            return {"error": "Not authenticated with Gmail"}
        
        try:
            results = service.users().messages().list(
                userId='me',
                maxResults=max_results,
                q='in:inbox'
            ).execute()
            
            messages = results.get('messages', [])
            emails = []
            
            for message in messages:
                email_data = self._get_message_details(service, message['id'])
                if email_data:
                    emails.append(email_data)
            
            print(f"[Gmail] Fetched {len(emails)} emails from inbox")
            return {"emails": emails}
        except RefreshError as e:
            # Token expired and couldn't refresh
            print(f"[Gmail] Token refresh failed: {e}")
            self._clear_credentials()
            return {"error": "Authentication expired. Please log in again."}
        except Exception as e:
            print(f"[Gmail] Error fetching emails: {e}")
            import traceback
            traceback.print_exc()
            return {"error": str(e)}
    
    def _extract_body(self, payload):
        """Recursively extract text body from MIME payload."""
        plain_parts = []
        html_parts = []

        def _walk(part):
            mime = part.get('mimeType', '')
            data = part.get('body', {}).get('data', '')

            if mime == 'text/plain' and data:
                plain_parts.append(base64.urlsafe_b64decode(data).decode('utf-8', errors='replace'))
            elif mime == 'text/html' and data:
                html_parts.append(base64.urlsafe_b64decode(data).decode('utf-8', errors='replace'))

            for sub in part.get('parts', []):
                _walk(sub)

        _walk(payload)

        if plain_parts:
            return '\n'.join(plain_parts)

        if html_parts:
            import re
            html = '\n'.join(html_parts)
            html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL)
            html = re.sub(r'<br\s*/?\s*>', '\n', html, flags=re.IGNORECASE)
            html = re.sub(r'</?p[^>]*>', '\n', html, flags=re.IGNORECASE)
            html = re.sub(r'</?div[^>]*>', '\n', html, flags=re.IGNORECASE)
            html = re.sub(r'<[^>]+>', '', html)
            html = re.sub(r'&nbsp;', ' ', html)
            html = re.sub(r'&amp;', '&', html)
            html = re.sub(r'&lt;', '<', html)
            html = re.sub(r'&gt;', '>', html)
            html = re.sub(r'&#\d+;', '', html)
            html = re.sub(r'\n{3,}', '\n\n', html)
            return html.strip()

        return ''

    def _get_message_details(self, service, message_id):
        """Get details of a specific email message."""
        try:
            message = service.users().messages().get(
                userId='me',
                id=message_id,
                format='full'
            ).execute()
            
            headers = message['payload'].get('headers', [])
            subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'No Subject')
            from_addr = next((h['value'] for h in headers if h['name'] == 'From'), 'Unknown')
            date = next((h['value'] for h in headers if h['name'] == 'Date'), '')
            
            body = self._extract_body(message['payload'])
            
            return {
                'id': message_id,
                'subject': subject,
                'from': from_addr,
                'date': date,
                'body': body
            }
        except Exception as e:
            print(f"Error getting message details: {e}")
            return None
    
    def send_email(self, to, subject, body):
        """Send an email through Gmail."""
        service = self.get_service()
        if service is None:
            return {"error": "Not authenticated with Gmail"}
        
        try:
            message = self._create_message('me', to, subject, body)
            
            send_message = service.users().messages().send(
                userId='me',
                body=message
            ).execute()
            
            return {
                "success": True,
                "message_id": send_message['id']
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _create_message(self, sender, to, subject, message_text):
        """Create a message for sending."""
        from email.mime.text import MIMEText
        
        credentials = self._load_credentials()
        user_email = self._get_email_from_credentials(credentials)
        
        message = MIMEText(message_text)
        message['to'] = to
        message['from'] = user_email
        message['subject'] = subject
        
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        return {'raw': raw}
    
    def _get_email_from_credentials(self, credentials):
        """Get email address from credentials."""
        try:
            service = build('gmail', 'v1', credentials=credentials)
            profile = service.users().getProfile(userId='me').execute()
            return profile.get('emailAddress', 'unknown@gmail.com')
        except:
            return 'unknown@gmail.com'
    
    def _clear_credentials(self):
        """Clear saved credentials."""
        if self.token_file.exists():
            self.token_file.unlink()
        self.service = None
    
    def is_authenticated(self):
        """Check if user is authenticated with Gmail."""
        return self._load_credentials() is not None
